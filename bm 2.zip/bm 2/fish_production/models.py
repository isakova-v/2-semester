from django.db import models

#создание класса с катерами (Софья)
class Launch(models.Model):
    name = models.CharField(max_length=100)
    type = models.CharField(max_length=100)
    displacement = models.IntegerField()
    constructiondate = models.IntegerField()

    def __str__(self):
        return self.name + ', тип: ' + self.type + ', водоизмещение: ' + str(self.displacement) + ', дата постройки: ' + str(self.constructiondate)
#создание класса с людьми (Софья)
class Man(models.Model):
    fio = models.CharField(max_length=100)
    adress = models.CharField(max_length=100)
    post = models.CharField(max_length=100)


    def __str__(self):
        return self.fio  + ', должность: ' + self.post + ', адрес: ' + self.adress

#сопоставление катеров с людьми, даты плаванья (Софья)
class ManLaunch(models.Model):
    launch = models.ForeignKey(Launch, on_delete=models.CASCADE)
    man = models.ManyToManyField(Man, null=True, blank=True)
    dateout = models.IntegerField()
    datein = models.IntegerField()

    def __str__(self):
        return 'катер: ' + str(self.launch) + ' дата выхода: ' + str(self.dateout) +' дата возвращения: ' + str(self.datein)

#таблица для регистрации веса и качества пойманной рыбы на одной банке(Виолетта):
class Fish(models.Model):
    banka = models.CharField(max_length=100, default=0)
    datein1 = models.IntegerField(default=0)
    dateout1 = models.IntegerField(default=0)
    fishsort = models.CharField(max_length=100)
    weight = models.IntegerField()
    quality = models.CharField(max_length=100)

    def __str__(self):
        return str(self.fishsort) + ' весом ' + str(self.weight) + ' кг; качество: ' + str(self.quality) + ' поймана на банке ' + str(self.banka)

#сопоставление посещенных банок с рейсом (Виолетта)
class FishingTrip(models.Model):
    trip = models.IntegerField(default=0)
    manlaunch = models.ForeignKey(ManLaunch, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=0) #ну не придумала я ничего лучше, пусть пользователи отмечают количество банок и заполняют их названия вручную
    banka = models.ManyToManyField(Fish, null=True, blank=True)

    def __str__(self):
        return 'рейс номер ' + str(self.trip) + ' посетил ' + str(self.quantity) + ' банок'


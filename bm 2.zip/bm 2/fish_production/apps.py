from django.apps import AppConfig


class FishProductionConfig(AppConfig):
    name = 'fish_production'

#пути для /api (Софья, Виолетта - пути для Fish)
from django.urls import path

from fish_production.views import LaunchList, LaunchDetail, ManList, ManDetail, ManLaunchList, ManLaunchDetail, \
    FishList, FishDetail, FishingTripList, FishingTripDetail

urlpatterns = [
    path('launch/', LaunchList.as_view()),
    path('launch/<int:pk>/', LaunchDetail.as_view()),
    path('man/', ManList.as_view()),
    path('man/<int:pk>/', ManDetail.as_view()),
    path('manlaunch/', ManLaunchList.as_view()),
    path('manlaunch/<int:pk>/', ManLaunchDetail.as_view()),
    path('fish/', FishList.as_view()),
    path('fish/<int:pk>/', FishDetail.as_view()),
    path('fishingtrip/', FishingTripList.as_view()),
    path('fishingtrip/<int:pk>/', FishingTripDetail.as_view()),
    ]

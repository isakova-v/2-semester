from django.contrib import admin

from bio_tech.models import Nematoda, ParametrsWorm, Worm, TypesOfWorm

admin.site.register(Nematoda)
admin.site.register(ParametrsWorm)
admin.site.register(Worm)
admin.site.register(TypesOfWorm)
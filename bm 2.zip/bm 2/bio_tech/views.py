from rest_framework import generics
from django.shortcuts import render

# Create your views here.
from bio_tech.models import Worm
from bio_tech.serializers import WormSerializer


class WormList(generics.ListCreateAPIView):
    def get_queryset(self):
        queryset = Worm.objects.all()
        symbols = self.request.query_params.get('params', None)
        if symbols is not None:
            queryset = queryset.filter(name__icontains=symbols).order_by('name')
        return queryset
    serializer_class = WormSerializer



class WormDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Worm.objects.all()
    serializer_class = WormSerializer

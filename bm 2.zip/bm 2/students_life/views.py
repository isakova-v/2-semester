from django.shortcuts import render
from rest_framework import generics

from students_life.models import Student, Room, StudentInRoom
from students_life.serializers import StudentSerializer, RoomSerializer, StudentInRoomSerializer


class StudentList(generics.ListCreateAPIView):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer

class StudentDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer

class RoomList(generics.ListCreateAPIView):
    queryset = Room.objects.all()
    serializer_class = RoomSerializer

class RoomDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Room.objects.all()
    serializer_class = RoomSerializer

class StudentInRoomList(generics.ListCreateAPIView):
    queryset = StudentInRoom.objects.all()
    serializer_class = StudentInRoomSerializer

class StudentInRoomDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = StudentInRoom.objects.all()
    serializer_class = StudentInRoomSerializer

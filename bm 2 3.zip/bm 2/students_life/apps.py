from django.apps import AppConfig


class StudentsLifeConfig(AppConfig):
    name = 'students_life'

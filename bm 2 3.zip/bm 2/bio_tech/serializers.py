from rest_framework import serializers

from bio_tech.models import Worm

class WormSerializer(serializers.ModelSerializer):
    class Meta:
        fields ="__all__"
        model = Worm

#создание serializers (Софья, Виолетта)
from rest_framework import serializers

from fish_production.models import Launch, Man, ManLaunch, Fish, FishingTrip


class LaunchSerializer(serializers.ModelSerializer):
    class Meta:
        fields = '__all__'
        model = Launch


class ManSerializer(serializers.ModelSerializer):
    class Meta:
        fields = '__all__'
        model = Man


class ManLaunchSerializer(serializers.ModelSerializer):
    class Meta:
        fields = '__all__'
        model = ManLaunch

class FishSerializer(serializers.ModelSerializer):
    class Meta:
        fields = '__all__'
        model = Fish

class FishingTripSerializer(serializers.ModelSerializer):
    class Meta:
        fields = '__all__'
        model = FishingTrip
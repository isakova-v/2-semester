from django.contrib import admin

from fish_production.models import Launch, Man, ManLaunch, Fish, FishingTrip

admin.site.register(Launch)
admin.site.register(Man)
admin.site.register(ManLaunch)
admin.site.register(Fish)
admin.site.register(FishingTrip)

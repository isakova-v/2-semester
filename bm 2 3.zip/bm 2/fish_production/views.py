from django.shortcuts import render
from rest_framework import generics

from fish_production.models import Launch, Man, ManLaunch, Fish, FishingTrip
from fish_production.serializers import LaunchSerializer, ManSerializer, ManLaunchSerializer, FishSerializer, \
    FishingTripSerializer


class LaunchList(generics.ListCreateAPIView):
    queryset = Launch.objects.all()
    serializer_class = LaunchSerializer


class LaunchDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Launch.objects.all()
    serializer_class = LaunchSerializer


class ManList(generics.ListCreateAPIView):
    queryset = Man.objects.all()
    serializer_class = ManSerializer


class ManDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Man.objects.all()
    serializer_class = ManSerializer


class ManLaunchDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = ManLaunch.objects.all()
    serializer_class = ManLaunchSerializer


class ManLaunchList(generics.ListCreateAPIView):
    serializer_class = ManLaunchSerializer
#функция, выводящая катера с определенной датой выхода через запрос ?dateout= (Софья)
    def get_queryset(self):
        queryset = ManLaunch.objects.all()
        dateout = self.request.query_params.get('dateout', None)
        print(dateout)
        launch_queryset = ManLaunch.objects.filter(dateout__contains=dateout).all()
        for launch in launch_queryset:
            print('launch_queryset', launch)
        print('---------')


#created by Violetta (def by Nick)
class FishList(generics.ListCreateAPIView):
    queryset = Fish.objects.all()
    serializer_class = FishSerializer

    def get_queryset(self):
        queryset1 = Fish.objects.all()
        queryset2 = FishingTrip.objects.all()
        quality = self.request.query_params.get('quality', None)
        print(quality)
        banka_queryset1 = Fish.objects.filter(quality__contains=quality).all()
        for banka in banka_queryset1:
            trip_queryset2 = FishingTrip.objects.filter(banka__contains=banka).all()
            for trip in trip_queryset2:
                print('trip_queryset', trip)
        print('---------')

class FishDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Fish.objects.all()
    serializer_class = FishSerializer

class FishingTripList(generics.ListCreateAPIView):
    queryset = FishingTrip.objects.all()
    serializer_class = FishingTripSerializer

    def get_queryset(self): #(Violetta)
        queryset = FishingTrip.objects.all()
        quantity = self.request.query_params.get('quantity', None)
        print(quantity)
        trip_queryset = FishingTrip.objects.filter(quantity__gte=quantity).all()
        for trip in trip_queryset:
            print('trip_queryset', trip)
        print( '---------' )


class FishingTripDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = FishingTrip.objects.all()
    serializer_class = FishingTripSerializer
